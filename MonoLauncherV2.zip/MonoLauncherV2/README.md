# Mono Launcher V2
Kotlin + Jetpack Compose launcher (`com.samuel.monolauncher`, minSdk 26, targetSdk 34). V1 is kept separately and untouched.

## What's new in V2
Home (dot-matrix clock, pinned apps, rounded dock), App drawer (search, A–Z index, 4/5 columns), Settings (Appearance, Home screen, App drawer, Clock & date, Behaviour, Wallpaper, About), Theme selector, Wallpaper picker (Android Photo Picker), Dock editor (add / remove / drag to reorder), Default Home guidance, optional launch fade.
V1 settings (theme, 24h clock, dock) carry over because the storage keys are unchanged.

## Build
- **GitHub Actions**: push to GitHub; `.github/workflows/build.yml` runs unit tests and `gradle assembleDebug` on Ubuntu and uploads `app-debug.apk` as the `app-debug` artifact.
- **Android Studio**: open the folder (JDK 17), sync, Build > Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk`.
- The Gradle wrapper jar/scripts are not included; the workflow installs Gradle 8.7 directly. Run `gradle wrapper` once locally if you want `./gradlew`.

## Set as Home app
Press Home > Mono Launcher > Always, or Settings > Apps > Default apps > Home app. In-app: Settings > About (or Home screen) > Default Home app.

## Differences from the reference image
- Icons: real app icons clipped to circles with a grayscale filter (not redrawn glyphs). Themed monochrome icons (Android 13+) are not used.
- Wallpaper: applied inside Mono Launcher only (no system-wallpaper permission). Built-in wallpapers are drawn in code; the "+" tile opens the Photo Picker.
- Dock: up to 4 apps plus a fixed drawer button; "Recommended" is "Add apps" (no usage data is read).
- Home apps are separate from the dock: long-press an app > Add to home screen / Add to dock.
- Settings and Theme have no back arrow, as in the reference; use system Back.
