package com.samuel.monolauncher

import com.samuel.monolauncher.ui.DotFont
import org.junit.Assert.*
import org.junit.Test

class DotFontTest {
    @Test fun columnsForClockText() = assertEquals(25, DotFont.columns("09:41"))
    @Test fun matrixHasSevenRowsOfEqualWidth() {
        val m = DotFont.matrix("12:30")
        assertEquals(7, m.size)
        assertTrue(m.all { it.size == DotFont.columns("12:30") })
    }
    @Test fun digitOneHasLitDots() = assertTrue(DotFont.matrix("1")[0].any { it })
}
