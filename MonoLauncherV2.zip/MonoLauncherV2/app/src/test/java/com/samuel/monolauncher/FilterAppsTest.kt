package com.samuel.monolauncher

import com.samuel.monolauncher.data.AppInfo
import com.samuel.monolauncher.data.filterApps
import org.junit.Assert.assertEquals
import org.junit.Test

class FilterAppsTest {
    private val apps = listOf(AppInfo("Camera", "a.cam", "A"), AppInfo("Clock", "a.clk", "B"), AppInfo("Maps", "a.map", "C"))
    @Test fun blankQueryReturnsAll() = assertEquals(3, filterApps(apps, "  ").size)
    @Test fun matchesCaseInsensitively() = assertEquals(listOf("Camera"), filterApps(apps, "cAm").map { it.label })
    @Test fun noMatchReturnsEmpty() = assertEquals(0, filterApps(apps, "zzz").size)
}
