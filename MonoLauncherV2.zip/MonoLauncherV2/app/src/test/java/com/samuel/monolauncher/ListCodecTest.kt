package com.samuel.monolauncher

import com.samuel.monolauncher.data.decodeList
import com.samuel.monolauncher.data.encodeList
import org.junit.Assert.assertEquals
import org.junit.Test

class ListCodecTest {
    @Test fun roundTrip() = assertEquals(listOf("a.b", "c.d"), decodeList(encodeList(listOf("a.b", "c.d"))))
    @Test fun nullAndBlankGiveEmpty() { assertEquals(emptyList<String>(), decodeList(null)); assertEquals(emptyList<String>(), decodeList("")) }
}
