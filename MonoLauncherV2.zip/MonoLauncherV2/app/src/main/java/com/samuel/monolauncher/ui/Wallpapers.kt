package com.samuel.monolauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale

const val BUILTIN_COUNT = 3

@Composable
fun BuiltInWallpaper(index: Int, modifier: Modifier = Modifier) {
    Canvas(modifier.clipToBounds()) {
        val w = size.width; val h = size.height
        val base = Color(0xFF09090A)
        drawRect(base)
        when (index) {
            0 -> { // planet limb
                val c = Offset(w, h * 0.62f); val r = w * 1.05f
                drawCircle(
                    Brush.radialGradient(listOf(Color(0xFF4A4B4F), Color(0xFF1A1A1C), base),
                        center = Offset(c.x - r * 0.45f, c.y - r * 0.55f), radius = r * 1.4f),
                    radius = r, center = c)
            }
            1 -> { // dusk ridge
                drawRect(Brush.verticalGradient(listOf(Color(0xFF2B2C30), base)), size = Size(w, h * 0.75f))
                val p = Path().apply {
                    moveTo(0f, h * 0.7f)
                    quadraticBezierTo(w * 0.3f, h * 0.5f, w * 0.55f, h * 0.68f)
                    quadraticBezierTo(w * 0.8f, h * 0.82f, w, h * 0.6f)
                    lineTo(w, h); lineTo(0f, h); close()
                }
                drawPath(p, Color(0xFF151517))
            }
            else -> { // soft glow
                val c = Offset(w * 0.5f, h * 0.35f)
                drawCircle(Brush.radialGradient(listOf(Color(0xFF2A2A2D), base), center = c, radius = w), radius = w, center = c)
            }
        }
    }
}

/** wallpaperId is "builtin:N" or "custom". */
@Composable
fun WallpaperBackground(wallpaperId: String, custom: ImageBitmap?, modifier: Modifier = Modifier) {
    if (wallpaperId == "custom" && custom != null) {
        Image(bitmap = custom, contentDescription = null, modifier = modifier, contentScale = ContentScale.Crop)
    } else {
        val idx = wallpaperId.removePrefix("builtin:").toIntOrNull()?.coerceIn(0, BUILTIN_COUNT - 1) ?: 0
        BuiltInWallpaper(idx, modifier)
    }
}
