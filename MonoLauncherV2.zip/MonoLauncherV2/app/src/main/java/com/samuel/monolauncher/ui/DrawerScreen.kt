package com.samuel.monolauncher.ui

import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.samuel.monolauncher.data.*
import kotlinx.coroutines.launch

@Composable
fun DrawerScreen(
    s: Settings, apps: List<AppInfo>, repo: AppRepository,
    onLaunch: (AppInfo) -> Unit, onMenu: (AppInfo) -> Unit, onSettings: () -> Unit, onToggleSort: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var menuOpen by remember { mutableStateOf(false) }
    val list = remember(apps, query, s.sortDesc) {
        filterApps(apps, query).let { if (s.sortDesc) it.reversed() else it }
    }
    val firstIndex = remember(list) {
        val m = HashMap<Char, Int>()
        list.forEachIndexed { i, a ->
            val c = a.label.firstOrNull()?.uppercaseChar()
            if (c != null && c in 'A'..'Z' && c !in m) m[c] = i
        }
        m
    }
    val gridState = rememberLazyGridState()
    val scope = rememberCoroutineScope()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (s.autoKeyboard) runCatching { focus.requestFocus() } }
    val c = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        TextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search apps…") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = {
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "More options") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text(if (s.sortDesc) "Sort A–Z" else "Sort Z–A") },
                            onClick = { menuOpen = false; onToggleSort() })
                        DropdownMenuItem(text = { Text("Settings") }, onClick = { menuOpen = false; onSettings() })
                    }
                }
            },
            shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = c.surfaceVariant, unfocusedContainerColor = c.surfaceVariant,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                disabledIndicatorColor = Color.Transparent
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp).focusRequester(focus)
        )
        Row(Modifier.weight(1f)) {
            if (list.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxHeight(), contentAlignment = Alignment.Center) { Text("No apps found") }
            } else {
                LazyVerticalGrid(GridCells.Fixed(s.drawerColumns), Modifier.weight(1f), gridState,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)) {
                    items(list, key = { it.packageName }) { app ->
                        AppTile(app, repo, s.monoIcons, true, c.onBackground, { onLaunch(app) }, { onMenu(app) },
                            Modifier.fillMaxWidth().padding(vertical = 6.dp))
                    }
                }
                if (s.alphabetIndex && query.isBlank()) {
                    AlphabetIndex(firstIndex) { idx -> scope.launch { gridState.scrollToItem(idx) } }
                }
            }
        }
    }
}

@Composable
fun AlphabetIndex(first: Map<Char, Int>, onPick: (Int) -> Unit) {
    val letters = remember { ('A'..'Z').toList() }
    val pickAt = { y: Float, h: Int ->
        val i = (y / h * letters.size).toInt().coerceIn(0, letters.size - 1)
        first[letters[i]]?.let(onPick)
        Unit
    }
    Column(
        Modifier.width(24.dp).fillMaxHeight().padding(vertical = 8.dp)
            .pointerInput(first) { detectTapGestures { o -> pickAt(o.y, size.height) } }
            .pointerInput(first) { detectVerticalDragGestures { change, _ -> change.consume(); pickAt(change.position.y, size.height) } },
        verticalArrangement = Arrangement.SpaceEvenly, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        letters.forEach { l ->
            Text(l.toString(), fontSize = 9.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = if (l in first) 0.8f else 0.25f))
        }
    }
}
