package com.samuel.monolauncher.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.samuel.monolauncher.data.ThemeMode

@Composable
fun isDark(mode: ThemeMode) = when (mode) {
    ThemeMode.SYSTEM -> isSystemInDarkTheme()
    ThemeMode.LIGHT -> false
    ThemeMode.DARK -> true
}

@Composable
fun MonoTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val scheme = if (isDark(mode))
        darkColorScheme(
            background = Color(0xFF0B0B0C), surface = Color(0xFF0B0B0C), surfaceVariant = Color(0xFF1A1B1D),
            onBackground = Color(0xFFF4F4F4), onSurface = Color(0xFFF4F4F4), onSurfaceVariant = Color(0xFF9A9A9E),
            primary = Color(0xFFEDEDED), onPrimary = Color(0xFF0B0B0C), outline = Color(0xFF2C2D30)
        )
    else
        lightColorScheme(
            background = Color(0xFFF2F0EB), surface = Color(0xFFF2F0EB), surfaceVariant = Color(0xFFE4E1DA),
            onBackground = Color(0xFF0B0B0C), onSurface = Color(0xFF0B0B0C), onSurfaceVariant = Color(0xFF6B6B6E),
            primary = Color(0xFF0B0B0C), onPrimary = Color(0xFFF2F0EB), outline = Color(0xFFCFCBC3)
        )
    MaterialTheme(colorScheme = scheme, content = content)
}
