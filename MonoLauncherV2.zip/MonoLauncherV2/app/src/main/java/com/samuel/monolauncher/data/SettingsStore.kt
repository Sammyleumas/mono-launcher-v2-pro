package com.samuel.monolauncher.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("mono_settings")

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class ClockStyle { DOT, PLAIN }

fun encodeList(l: List<String>): String = l.joinToString(",")
fun decodeList(s: String?): List<String> = s?.split(",")?.filter { it.isNotBlank() } ?: emptyList()

data class Settings(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val use24h: Boolean = true,
    val dock: List<String> = emptyList(),
    val homeApps: List<String> = emptyList(),
    val monoIcons: Boolean = true,
    val homeLabels: Boolean = true,
    val drawerColumns: Int = 4,
    val alphabetIndex: Boolean = true,
    val sortDesc: Boolean = false,
    val showClock: Boolean = true,
    val clockStyle: ClockStyle = ClockStyle.DOT,
    val clockSize: Int = 1,
    val showDate: Boolean = true,
    val swipeUp: Boolean = true,
    val launchAnim: Boolean = true,
    val autoKeyboard: Boolean = false,
    val wallpaper: String = "builtin:0"
)

object Keys {
    // THEME, H24 and DOCK keep their V1 names so V1 settings carry over.
    val THEME = stringPreferencesKey("theme")
    val H24 = booleanPreferencesKey("use24h")
    val DOCK = stringPreferencesKey("favorites")
    val HOME_APPS = stringPreferencesKey("home_apps")
    val MONO = booleanPreferencesKey("mono_icons")
    val HOME_LABELS = booleanPreferencesKey("home_labels")
    val COLUMNS = intPreferencesKey("drawer_columns")
    val ALPHABET = booleanPreferencesKey("alphabet_index")
    val SORT_DESC = booleanPreferencesKey("sort_desc")
    val SHOW_CLOCK = booleanPreferencesKey("show_clock")
    val CLOCK_STYLE = stringPreferencesKey("clock_style")
    val CLOCK_SIZE = intPreferencesKey("clock_size")
    val SHOW_DATE = booleanPreferencesKey("show_date")
    val SWIPE_UP = booleanPreferencesKey("swipe_up")
    val LAUNCH_ANIM = booleanPreferencesKey("launch_anim")
    val AUTO_KB = booleanPreferencesKey("auto_keyboard")
    val WALLPAPER = stringPreferencesKey("wallpaper")
}

private inline fun <reified E : Enum<E>> parse(s: String?, d: E): E =
    runCatching { enumValueOf<E>(s ?: d.name) }.getOrDefault(d)

class SettingsStore(private val context: Context) {
    val settings: Flow<Settings> = context.dataStore.data.map { p ->
        Settings(
            theme = parse(p[Keys.THEME], ThemeMode.SYSTEM),
            use24h = p[Keys.H24] ?: true,
            dock = decodeList(p[Keys.DOCK]),
            homeApps = decodeList(p[Keys.HOME_APPS]),
            monoIcons = p[Keys.MONO] ?: true,
            homeLabels = p[Keys.HOME_LABELS] ?: true,
            drawerColumns = (p[Keys.COLUMNS] ?: 4).coerceIn(3, 6),
            alphabetIndex = p[Keys.ALPHABET] ?: true,
            sortDesc = p[Keys.SORT_DESC] ?: false,
            showClock = p[Keys.SHOW_CLOCK] ?: true,
            clockStyle = parse(p[Keys.CLOCK_STYLE], ClockStyle.DOT),
            clockSize = (p[Keys.CLOCK_SIZE] ?: 1).coerceIn(0, 2),
            showDate = p[Keys.SHOW_DATE] ?: true,
            swipeUp = p[Keys.SWIPE_UP] ?: true,
            launchAnim = p[Keys.LAUNCH_ANIM] ?: true,
            autoKeyboard = p[Keys.AUTO_KB] ?: false,
            wallpaper = p[Keys.WALLPAPER] ?: "builtin:0"
        )
    }

    suspend fun <T> put(key: Preferences.Key<T>, value: T) { context.dataStore.edit { it[key] = value } }
}
