package com.samuel.monolauncher

import android.app.Application
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.datastore.preferences.core.Preferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.samuel.monolauncher.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class Screen {
    HOME, DRAWER, SETTINGS, S_APPEARANCE, S_HOME, S_DRAWER, S_CLOCK, S_BEHAVIOUR, S_ABOUT,
    THEME, WALLPAPER, EDIT_DOCK, DEFAULT_HOME
}
const val MAX_DOCK = 4
const val MAX_HOME = 8

class LauncherViewModel(app: Application) : AndroidViewModel(app) {
    val repo = AppRepository(app)
    private val store = SettingsStore(app)
    private val walls = WallpaperStore(app)

    private val _apps = MutableStateFlow<List<AppInfo>>(emptyList())
    val apps = _apps.asStateFlow()
    private val _tick = MutableStateFlow(0)
    val tick = _tick.asStateFlow()
    private val _custom = MutableStateFlow<ImageBitmap?>(null)
    val customWallpaper = _custom.asStateFlow()
    val settings = store.settings.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())

    private val stack = ArrayDeque<Screen>()
    private val _screen = MutableStateFlow(Screen.HOME)
    val screen = _screen.asStateFlow()

    init { viewModelScope.launch { _custom.value = walls.load() } }

    fun nav(s: Screen) { stack.addLast(_screen.value); _screen.value = s }
    fun back() { _screen.value = stack.removeLastOrNull() ?: Screen.HOME }
    fun home() { stack.clear(); _screen.value = Screen.HOME }

    fun refresh() {
        _tick.value++
        viewModelScope.launch { _apps.value = withContext(Dispatchers.IO) { repo.loadApps() } }
    }

    fun <T> put(key: Preferences.Key<T>, value: T) { viewModelScope.launch { store.put(key, value) } }

    fun saveDock(list: List<String>) = put(Keys.DOCK, encodeList(list))
    fun resetHome() { saveDock(emptyList()); put(Keys.HOME_APPS, "") }

    /** Returns false when the dock is full. */
    fun toggleDock(pkg: String): Boolean {
        val cur = settings.value.dock
        val next = when {
            pkg in cur -> cur - pkg
            cur.size >= MAX_DOCK -> return false
            else -> cur + pkg
        }
        saveDock(next); return true
    }

    /** Returns false when the home screen is full. */
    fun toggleHome(pkg: String): Boolean {
        val cur = settings.value.homeApps
        val next = when {
            pkg in cur -> cur - pkg
            cur.size >= MAX_HOME -> return false
            else -> cur + pkg
        }
        put(Keys.HOME_APPS, encodeList(next)); return true
    }

    fun importWallpaper(uri: Uri, onDone: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = walls.import(uri)
            if (ok) _custom.value = walls.load()
            onDone(ok)
        }
    }
}
