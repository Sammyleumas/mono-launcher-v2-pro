package com.samuel.monolauncher.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Copies a picked image into app-private storage, downscaled to roughly screen size. */
class WallpaperStore(private val ctx: Context) {
    private val file get() = File(ctx.filesDir, "wallpaper_custom.jpg")

    suspend fun import(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val dm = ctx.resources.displayMetrics
            val target = maxOf(dm.widthPixels, dm.heightPixels)
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            val boundsStream = ctx.contentResolver.openInputStream(uri) ?: return@withContext false
            boundsStream.use { BitmapFactory.decodeStream(it, null, bounds) } // returns null by design
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@withContext false
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= target) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return@withContext false
            file.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            bmp.recycle()
            true
        } catch (e: Exception) { false } catch (e: OutOfMemoryError) { false }
    }

    suspend fun load(): ImageBitmap? = withContext(Dispatchers.IO) {
        if (!file.exists()) null
        else try { BitmapFactory.decodeFile(file.path)?.asImageBitmap() }
        catch (e: Exception) { null } catch (e: OutOfMemoryError) { null }
    }
}
