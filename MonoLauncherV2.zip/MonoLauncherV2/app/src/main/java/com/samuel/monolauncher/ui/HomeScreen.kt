package com.samuel.monolauncher.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.samuel.monolauncher.MAX_DOCK
import com.samuel.monolauncher.MAX_HOME
import com.samuel.monolauncher.data.*
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    s: Settings, apps: List<AppInfo>, custom: ImageBitmap?, repo: AppRepository,
    onLaunch: (AppInfo) -> Unit, onMenu: (AppInfo) -> Unit, onDrawer: () -> Unit, onEditDock: () -> Unit
) {
    val byPkg = remember(apps) { apps.associateBy { it.packageName } }
    val homeApps = s.homeApps.mapNotNull { byPkg[it] }.take(MAX_HOME)
    val dock = s.dock.mapNotNull { byPkg[it] }.take(MAX_DOCK)
    val white = Color.White
    Box(Modifier.fillMaxSize()) {
        WallpaperBackground(s.wallpaper, custom, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x66000000), Color.Transparent, Color(0x99000000)))))
        CompositionLocalProvider(LocalContentColor provides white) {
            Column(
                Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 20.dp)
                    .pointerInput(s.swipeUp) {
                        if (!s.swipeUp) return@pointerInput
                        var total = 0f
                        detectVerticalDragGestures(
                            onDragStart = { total = 0f },
                            onDragEnd = { if (total < -120f) onDrawer() },
                            onVerticalDrag = { _, d -> total += d }
                        )
                    }
            ) {
                Spacer(Modifier.height(24.dp))
                if (s.showClock || s.showDate) ClockBlock(s)
                Spacer(Modifier.weight(1f))
                homeApps.chunked(4).forEach { rowApps ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        rowApps.forEach { a ->
                            AppTile(a, repo, s.monoIcons, s.homeLabels, white, { onLaunch(a) }, { onMenu(a) }, Modifier.weight(1f))
                        }
                        repeat(4 - rowApps.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                if (homeApps.isEmpty()) {
                    Text("Long-press an app in the drawer to add it to your home screen.", fontSize = 13.sp,
                        color = white.copy(alpha = 0.6f), modifier = Modifier.padding(vertical = 8.dp))
                }
                IconButton(onClick = onDrawer, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                    Icon(Icons.Filled.KeyboardArrowUp, "Open app drawer", tint = white.copy(alpha = 0.7f))
                }
                Surface(
                    shape = RoundedCornerShape(32.dp), color = white.copy(alpha = 0.10f),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(32.dp))
                        .combinedClickable(onClick = {}, onLongClick = onEditDock, onLongClickLabel = "Edit dock")
                ) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically) {
                        dock.forEach { a -> AppTile(a, repo, s.monoIcons, false, white, { onLaunch(a) }, { onMenu(a) }) }
                        Box(Modifier.size(56.dp).clip(CircleShape).clickable(onClickLabel = "All apps", onClick = onDrawer),
                            contentAlignment = Alignment.Center) { DotGridIcon(white) }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun ClockBlock(s: Settings) {
    val now by produceState(LocalDateTime.now()) {
        while (true) {
            value = LocalDateTime.now()
            delay(60_000L - (System.currentTimeMillis() % 60_000L))
        }
    }
    val text = now.format(DateTimeFormatter.ofPattern(if (s.use24h) "HH:mm" else "h:mm"))
    Column {
        if (s.showClock) {
            if (s.clockStyle == ClockStyle.DOT) {
                val frac = listOf(0.5f, 0.68f, 0.85f)[s.clockSize]
                DotClock(text, Color.White, Modifier.fillMaxWidth(frac).semantics { contentDescription = text })
            } else {
                Text(text, fontSize = listOf(56, 80, 104)[s.clockSize].sp, fontWeight = FontWeight.Light, fontFamily = FontFamily.Monospace)
            }
        }
        if (s.showDate) {
            Spacer(Modifier.height(10.dp))
            Text(now.format(DateTimeFormatter.ofPattern("EEE, MMM d", Locale.getDefault())), fontSize = 18.sp)
        }
    }
}
