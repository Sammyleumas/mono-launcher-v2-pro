package com.samuel.monolauncher.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.samuel.monolauncher.LauncherViewModel
import com.samuel.monolauncher.data.Keys
import com.samuel.monolauncher.data.Settings

@Composable
fun WallpaperScreen(s: Settings, custom: ImageBitmap?, vm: LauncherViewModel) {
    val ctx = LocalContext.current
    var selected by remember { mutableStateOf(s.wallpaper) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.importWallpaper(uri) { ok -> if (ok) selected = "custom" else ctx.toast("Couldn't use that image") }
    }
    val shape = RoundedCornerShape(16.dp)
    ScreenFrame("Wallpaper", vm::back) { ScrollBody {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            WallpaperBackground(selected, custom,
                Modifier.fillMaxWidth(0.6f).aspectRatio(9f / 16f).clip(RoundedCornerShape(24.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp)))
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            val ids = (0 until BUILTIN_COUNT).map { "builtin:$it" } + listOfNotNull(if (custom != null) "custom" else null)
            ids.forEach { id ->
                WallpaperBackground(id, custom,
                    Modifier.size(64.dp, 92.dp).clip(shape)
                        .border(if (id == selected) 2.dp else 1.dp,
                            if (id == selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.outline, shape)
                        .clickable { selected = id }
                        .semantics { contentDescription = "Wallpaper ${id.substringAfter(':')}" })
            }
            Box(Modifier.size(64.dp, 92.dp).clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)
                .clickable(onClickLabel = "Pick from photos") {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }, contentAlignment = Alignment.Center) { Icon(Icons.Filled.Add, "Pick from photos") }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = { vm.put(Keys.WALLPAPER, selected); ctx.toast("Wallpaper set") },
            shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Set wallpaper") }
    } }
}
