package com.samuel.monolauncher.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color

object DotFont {
    const val ROWS = 7
    private val digits = listOf(
        "01110,10001,10011,10101,11001,10001,01110", "00100,01100,00100,00100,00100,00100,01110",
        "01110,10001,00001,00010,00100,01000,11111", "11111,00010,00100,00010,00001,10001,01110",
        "00010,00110,01010,10010,11111,00010,00010", "11111,10000,11110,00001,00001,10001,01110",
        "00110,01000,10000,11110,10001,10001,01110", "11111,00001,00010,00100,01000,01000,01000",
        "01110,10001,10001,01110,10001,10001,01110", "01110,10001,10001,01111,00001,00010,01100"
    ).map { it.split(",") }
    private val colon = listOf("0", "0", "1", "0", "1", "0", "0")

    private fun glyph(c: Char): List<String> = if (c == ':') colon else digits[(c - '0').coerceIn(0, 9)]

    fun columns(text: String): Int = text.sumOf { glyph(it)[0].length } + (text.length - 1).coerceAtLeast(0)

    /** 7 rows x N columns, true = lit dot. One blank column between glyphs. */
    fun matrix(text: String): List<BooleanArray> {
        val cols = columns(text)
        return List(ROWS) { r ->
            val row = BooleanArray(cols)
            var x = 0
            text.forEach { ch ->
                val g = glyph(ch)[r]
                g.forEachIndexed { i, b -> row[x + i] = b == '1' }
                x += g.length + 1
            }
            row
        }
    }
}

@Composable
fun DotClock(text: String, color: Color, modifier: Modifier = Modifier) {
    val m = remember(text) { DotFont.matrix(text) }
    val cols = m[0].size
    androidx.compose.foundation.Canvas(modifier.aspectRatio(cols / DotFont.ROWS.toFloat())) {
        val pitch = size.width / cols
        for (r in 0 until DotFont.ROWS) for (c in 0 until cols)
            drawCircle(if (m[r][c]) color else color.copy(alpha = 0.10f), pitch * 0.34f, Offset(c * pitch + pitch / 2, r * pitch + pitch / 2))
    }
}
