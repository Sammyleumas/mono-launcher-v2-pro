package com.samuel.monolauncher.ui

import android.content.Intent
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.samuel.monolauncher.LauncherViewModel
import com.samuel.monolauncher.Screen
import com.samuel.monolauncher.data.*

private data class Cat(val icon: ImageVector, val title: String, val sub: String, val target: Screen)

@Composable
fun SettingsHome(vm: LauncherViewModel) {
    var q by remember { mutableStateOf("") }
    val cats = remember {
        listOf(
            Cat(Icons.Filled.Create, "Appearance", "Theme, wallpaper, icon style", Screen.S_APPEARANCE),
            Cat(Icons.Filled.Home, "Home screen", "Layout, dock, favourites", Screen.S_HOME),
            Cat(Icons.Filled.Menu, "App drawer", "Grid, search, sorting", Screen.S_DRAWER),
            Cat(Icons.Filled.DateRange, "Clock & date", "Visibility, size, format", Screen.S_CLOCK),
            Cat(Icons.Filled.Build, "Behaviour", "Gestures, animations", Screen.S_BEHAVIOUR),
            Cat(Icons.Filled.Star, "Wallpaper", "Choose a wallpaper", Screen.WALLPAPER),
            Cat(Icons.Filled.Info, "About", "Version, legal, feedback", Screen.S_ABOUT)
        )
    }
    val shown = cats.filter { q.isBlank() || it.title.contains(q, true) || it.sub.contains(q, true) }
    val c = MaterialTheme.colorScheme
    ScreenFrame("Settings", null) {
        TextField(
            value = q, onValueChange = { q = it }, singleLine = true, placeholder = { Text("Search settings…") },
            leadingIcon = { Icon(Icons.Filled.Search, null) }, shape = RoundedCornerShape(28.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = c.surfaceVariant, unfocusedContainerColor = c.surfaceVariant,
                focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp)
        )
        ScrollBody {
            Spacer(Modifier.height(8.dp))
            shown.forEach { NavRow(it.icon, it.title, it.sub) { vm.nav(it.target) } }
            if (shown.isEmpty()) Text("No matching settings", color = c.onSurfaceVariant, modifier = Modifier.padding(16.dp))
        }
    }
}

@Composable
fun SettingsSub(screen: Screen, s: Settings, vm: LauncherViewModel) {
    val ctx = LocalContext.current
    when (screen) {
        Screen.S_APPEARANCE -> ScreenFrame("Appearance", vm::back) { ScrollBody {
            NavRow(Icons.Filled.Create, "Theme", s.theme.name.lowercase().replaceFirstChar { it.uppercase() }) { vm.nav(Screen.THEME) }
            NavRow(Icons.Filled.Star, "Wallpaper", "Choose a wallpaper") { vm.nav(Screen.WALLPAPER) }
            ChoiceRow("Icon style", listOf("Monochrome", "Original colours"), if (s.monoIcons) 0 else 1) { vm.put(Keys.MONO, it == 0) }
        } }
        Screen.S_HOME -> ScreenFrame("Home screen", vm::back) { ScrollBody {
            NavRow(Icons.Filled.Edit, "Edit dock", "Add, remove and reorder") { vm.nav(Screen.EDIT_DOCK) }
            NavRow(Icons.Filled.Home, "Default Home app", "Make Mono Launcher your launcher") { vm.nav(Screen.DEFAULT_HOME) }
            SwitchRow("App labels", "Show names under home screen icons", s.homeLabels) { vm.put(Keys.HOME_LABELS, it) }
            ActionRow("Clear home apps and dock", "Removes all pinned apps") { vm.resetHome(); ctx.toast("Home screen cleared") }
        } }
        Screen.S_DRAWER -> ScreenFrame("App drawer", vm::back) { ScrollBody {
            ChoiceRow("Columns", listOf("4", "5"), s.drawerColumns - 4) { vm.put(Keys.COLUMNS, it + 4) }
            ChoiceRow("Sort order", listOf("A–Z", "Z–A"), if (s.sortDesc) 1 else 0) { vm.put(Keys.SORT_DESC, it == 1) }
            SwitchRow("Alphabet index", "Show A–Z scroller", s.alphabetIndex) { vm.put(Keys.ALPHABET, it) }
        } }
        Screen.S_CLOCK -> ScreenFrame("Clock & date", vm::back) { ScrollBody {
            SwitchRow("Show clock", null, s.showClock) { vm.put(Keys.SHOW_CLOCK, it) }
            SwitchRow("Show date", null, s.showDate) { vm.put(Keys.SHOW_DATE, it) }
            ChoiceRow("Clock style", listOf("Dot matrix", "Plain"), s.clockStyle.ordinal) { vm.put(Keys.CLOCK_STYLE, ClockStyle.values()[it].name) }
            ChoiceRow("Clock size", listOf("Small", "Medium", "Large"), s.clockSize) { vm.put(Keys.CLOCK_SIZE, it) }
            SwitchRow("24-hour format", null, s.use24h) { vm.put(Keys.H24, it) }
        } }
        Screen.S_BEHAVIOUR -> ScreenFrame("Behaviour", vm::back) { ScrollBody {
            SwitchRow("Swipe up for app drawer", "Swipe up on the home screen", s.swipeUp) { vm.put(Keys.SWIPE_UP, it) }
            SwitchRow("Launch animation", "Fade when opening apps", s.launchAnim) { vm.put(Keys.LAUNCH_ANIM, it) }
            SwitchRow("Keyboard on drawer open", "Focus search automatically", s.autoKeyboard) { vm.put(Keys.AUTO_KB, it) }
        } }
        Screen.S_ABOUT -> {
            val version = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "2.0" }
            ScreenFrame("About", vm::back) { ScrollBody {
                Text("Mono Launcher", fontSize = 22.sp, modifier = Modifier.padding(top = 8.dp))
                Text("Version $version", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(16.dp))
                Text("Mono Launcher collects no data, has no network access and requests no special permissions. " +
                    "It cannot replace the lock screen or notification shade.", fontSize = 14.sp)
                Spacer(Modifier.height(16.dp))
                NavRow(Icons.Filled.Home, "Default Home app", "Help selecting Mono Launcher") { vm.nav(Screen.DEFAULT_HOME) }
            } }
        }
        else -> {}
    }
}

@Composable
fun ThemeScreen(s: Settings, vm: LauncherViewModel) {
    ScreenFrame("Theme", null) { ScrollBody {
        Spacer(Modifier.height(8.dp))
        listOf(
            Triple(ThemeMode.LIGHT, "Light", "Clean and bright"),
            Triple(ThemeMode.DARK, "Dark", "Easy on the eyes"),
            Triple(ThemeMode.SYSTEM, "System", "Follow system theme")
        ).forEach { (mode, title, sub) ->
            val sel = s.theme == mode
            Row(
                Modifier.fillMaxWidth().padding(vertical = 6.dp).heightIn(min = 80.dp).clip(RoundedCornerShape(20.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .then(if (sel) Modifier.border(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f), RoundedCornerShape(20.dp)) else Modifier)
                    .selectable(selected = sel, onClick = { vm.put(Keys.THEME, mode.name) }, role = Role.RadioButton)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Swatch(mode)
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontSize = 16.sp)
                    Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                RadioButton(selected = sel, onClick = null)
            }
        }
    } }
}

@Composable
private fun Swatch(mode: ThemeMode) {
    val light = Color(0xFFF2F0EB); val dark = Color(0xFF0B0B0C)
    Canvas(Modifier.size(44.dp).clip(CircleShape).border(1.dp, Color.Gray.copy(alpha = 0.4f), CircleShape)) {
        when (mode) {
            ThemeMode.LIGHT -> drawCircle(light)
            ThemeMode.DARK -> drawCircle(dark)
            ThemeMode.SYSTEM -> {
                drawArc(light, 90f, 180f, true)
                drawArc(dark, 270f, 180f, true)
            }
        }
    }
}

@Composable
fun DefaultHomeScreen(vm: LauncherViewModel) {
    val ctx = LocalContext.current
    val tick by vm.tick.collectAsState()
    val isDefault = remember(tick) { vm.repo.isDefaultHome() }
    ScreenFrame("Default Home App", vm::back) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(32.dp))
            Box(Modifier.size(72.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant), contentAlignment = Alignment.Center) {
                DotGridIcon(MaterialTheme.colorScheme.onBackground, Modifier.size(28.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text(if (isDefault) "Mono Launcher is your default Home app" else "Set Mono Launcher as your default Home app",
                fontSize = 17.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("This lets Mono Launcher open when you press the Home button.", fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            Button(onClick = {
                try { ctx.startActivity(Intent(AndroidSettings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) {
                    try { ctx.startActivity(Intent(AndroidSettings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                    catch (e2: Exception) { ctx.toast("Couldn't open Settings") }
                }
            }, shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)) { Text("Open settings") }
            Spacer(Modifier.height(28.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Spacer(Modifier.height(16.dp))
            Text("If you can't select it directly, go to Settings > Apps > Default apps > Home app and choose Mono Launcher. " +
                "To switch back later, choose your previous launcher in the same place.", fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
    }
}
