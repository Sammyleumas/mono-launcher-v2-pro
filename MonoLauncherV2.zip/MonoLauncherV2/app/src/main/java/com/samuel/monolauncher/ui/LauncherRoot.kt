package com.samuel.monolauncher.ui

import android.content.Intent
import android.graphics.Color as AColor
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.samuel.monolauncher.*
import com.samuel.monolauncher.data.*

@Composable
fun LauncherRoot(vm: LauncherViewModel) {
    val s by vm.settings.collectAsState()
    val apps by vm.apps.collectAsState()
    val screen by vm.screen.collectAsState()
    val custom by vm.customWallpaper.collectAsState()
    val ctx = LocalContext.current
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }

    MonoTheme(s.theme) {
        val darkBars = isDark(s.theme) || screen == Screen.HOME
        SideEffect {
            val style = if (darkBars) SystemBarStyle.dark(AColor.TRANSPARENT)
            else SystemBarStyle.light(AColor.TRANSPARENT, AColor.TRANSPARENT)
            (ctx as? ComponentActivity)?.enableEdgeToEdge(style, style)
        }
        BackHandler(enabled = screen != Screen.HOME) { vm.back() }

        val launch: (AppInfo) -> Unit = { app ->
            if (!vm.repo.launch(app, s.launchAnim)) {
                ctx.toast("${app.label} can't be opened")
                vm.refresh()
            }
        }

        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background, contentColor = MaterialTheme.colorScheme.onBackground) {
            when (screen) {
                Screen.HOME -> HomeScreen(s, apps, custom, vm.repo, launch, { menuApp = it }, { vm.nav(Screen.DRAWER) }, { vm.nav(Screen.EDIT_DOCK) })
                Screen.DRAWER -> DrawerScreen(s, apps, vm.repo, launch, { menuApp = it }, { vm.nav(Screen.SETTINGS) },
                    { vm.put(Keys.SORT_DESC, !s.sortDesc) })
                Screen.SETTINGS -> SettingsHome(vm)
                Screen.THEME -> ThemeScreen(s, vm)
                Screen.WALLPAPER -> WallpaperScreen(s, custom, vm)
                Screen.EDIT_DOCK -> DockEditor(s, apps, vm.repo, { vm.saveDock(it); vm.back() }, { vm.back() })
                Screen.DEFAULT_HOME -> DefaultHomeScreen(vm)
                else -> SettingsSub(screen, s, vm)
            }
        }

        menuApp?.let { app -> AppMenu(app, s, vm) { menuApp = null } }
    }
}

@Composable
private fun AppMenu(app: AppInfo, s: Settings, vm: LauncherViewModel, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val pinned = app.packageName in s.homeApps
    val inDock = app.packageName in s.dock
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(app.label) }, confirmButton = {},
        text = {
            Column {
                MenuRow(if (pinned) "Remove from home screen" else "Add to home screen") {
                    if (!vm.toggleHome(app.packageName)) ctx.toast("Home screen is full ($MAX_HOME apps)")
                    onDismiss()
                }
                MenuRow(if (inDock) "Remove from dock" else "Add to dock") {
                    if (!vm.toggleDock(app.packageName)) ctx.toast("Dock is full ($MAX_DOCK apps)")
                    onDismiss()
                }
                MenuRow("App info") {
                    runCatching {
                        ctx.startActivity(Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${app.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    onDismiss()
                }
            }
        }
    )
}

@Composable
private fun MenuRow(text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable(onClick = onClick), verticalAlignment = Alignment.CenterVertically) {
        Text(text)
    }
}
