package com.samuel.monolauncher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.CustomAccessibilityAction
import androidx.compose.ui.semantics.customActions
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.samuel.monolauncher.MAX_DOCK
import com.samuel.monolauncher.data.*
import kotlin.math.roundToInt

private fun swapped(l: List<String>, i: Int, j: Int): List<String> =
    l.toMutableList().also { val t = it[i]; it[i] = it[j]; it[j] = t }

@Composable
fun DockEditor(s: Settings, apps: List<AppInfo>, repo: AppRepository, onSave: (List<String>) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    val byPkg = remember(apps) { apps.associateBy { it.packageName } }
    var draft by remember { mutableStateOf(s.dock.filter { it in byPkg }.take(MAX_DOCK)) }
    val draftNow = rememberUpdatedState(draft)
    val slotPx = with(LocalDensity.current) { 80.dp.toPx() } // 72dp slot + 8dp gap
    val c = MaterialTheme.colorScheme

    ScreenFrame("Edit dock", onCancel) {
        Text("Long-press and drag apps to rearrange", fontSize = 13.sp, color = c.onSurfaceVariant, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 20.dp).heightIn(min = 76.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            draft.forEach { pkg ->
                key(pkg) {
                    val app = byPkg[pkg] ?: return@key
                    var dx by remember { mutableFloatStateOf(0f) }
                    Box(
                        Modifier.width(72.dp).offset { IntOffset(dx.roundToInt(), 0) }.zIndex(if (dx != 0f) 1f else 0f)
                            .semantics {
                                customActions = listOf(
                                    CustomAccessibilityAction("Move left") {
                                        val i = draft.indexOf(pkg); if (i > 0) draft = swapped(draft, i, i - 1); true },
                                    CustomAccessibilityAction("Move right") {
                                        val i = draft.indexOf(pkg); if (i < draft.size - 1) draft = swapped(draft, i, i + 1); true }
                                )
                            }
                            .pointerInput(pkg) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = {}, onDragEnd = { dx = 0f }, onDragCancel = { dx = 0f },
                                    onDrag = { change, amount ->
                                        change.consume(); dx += amount.x
                                        val cur = draftNow.value; val i = cur.indexOf(pkg)
                                        if (dx > slotPx / 2 && i in 0 until cur.size - 1) { draft = swapped(cur, i, i + 1); dx -= slotPx }
                                        else if (dx < -slotPx / 2 && i > 0) { draft = swapped(cur, i, i - 1); dx += slotPx }
                                    }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(Modifier.size(72.dp).clip(RoundedCornerShape(20.dp)).background(c.surfaceVariant), contentAlignment = Alignment.Center) {
                            AppIcon(app, repo, s.monoIcons, c.onBackground)
                        }
                        Box(Modifier.align(Alignment.TopEnd).size(28.dp).clip(CircleShape).background(c.onBackground)
                            .clickable(onClickLabel = "Remove ${app.label} from dock") { draft = draft - pkg },
                            contentAlignment = Alignment.Center) { Text("−", color = c.background, fontSize = 16.sp) }
                    }
                }
            }
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(20.dp)).background(c.surfaceVariant), contentAlignment = Alignment.Center) {
                DotGridIcon(c.onBackground)
            }
        }
        Spacer(Modifier.height(16.dp))
        HorizontalDivider(color = c.outline, modifier = Modifier.padding(horizontal = 20.dp))
        Text("Add apps", fontSize = 13.sp, color = c.onSurfaceVariant, modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 4.dp))
        LazyVerticalGrid(GridCells.Fixed(4), Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 12.dp)) {
            items(apps.filter { it.packageName !in draft }, key = { it.packageName }) { app ->
                AppTile(app, repo, s.monoIcons, true, c.onBackground, {
                    if (draft.size < MAX_DOCK) draft = draft + app.packageName else ctx.toast("Dock is full ($MAX_DOCK apps)")
                }, {}, Modifier.fillMaxWidth().padding(vertical = 4.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onCancel, shape = RoundedCornerShape(28.dp), modifier = Modifier.weight(1f).heightIn(min = 52.dp)) { Text("Cancel") }
            Button(onClick = { onSave(draft) }, shape = RoundedCornerShape(28.dp), modifier = Modifier.weight(1f).heightIn(min = 52.dp)) { Text("Save") }
        }
    }
}
