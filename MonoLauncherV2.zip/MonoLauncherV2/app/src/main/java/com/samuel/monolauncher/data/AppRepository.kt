package com.samuel.monolauncher.data

import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

data class AppInfo(val label: String, val packageName: String, val activityName: String)

fun filterApps(apps: List<AppInfo>, query: String): List<AppInfo> {
    val q = query.trim()
    return if (q.isEmpty()) apps else apps.filter { it.label.contains(q, ignoreCase = true) }
}

class AppRepository(private val context: Context) {
    private val pm = context.packageManager
    private val icons = ConcurrentHashMap<String, ImageBitmap>()

    fun loadApps(): List<AppInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.name) }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    suspend fun icon(app: AppInfo): ImageBitmap? = withContext(Dispatchers.Default) {
        icons[app.packageName] ?: try {
            pm.getActivityIcon(ComponentName(app.packageName, app.activityName))
                .toBitmap(128, 128).asImageBitmap()
                .also { icons[app.packageName] = it }
        } catch (e: Exception) { null }
    }

    /** Returns false if the app is missing, disabled or cannot be started. */
    fun launch(app: AppInfo, animate: Boolean): Boolean = try {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(app.packageName, app.activityName))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        val opts = if (animate)
            ActivityOptions.makeCustomAnimation(context, android.R.anim.fade_in, android.R.anim.fade_out).toBundle()
        else null
        context.startActivity(i, opts)
        true
    } catch (e: RuntimeException) { false }

    fun isDefaultHome(): Boolean {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        return pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName == context.packageName
    }
}
